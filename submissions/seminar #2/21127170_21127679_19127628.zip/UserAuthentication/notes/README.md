Meeting notes and personal notes you want to share publicly
