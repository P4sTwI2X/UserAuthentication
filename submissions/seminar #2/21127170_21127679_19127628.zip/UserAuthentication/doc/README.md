Document repository, not to be confused with meeting and personal notes in 'Notes'
