# This is the property of group 15, class 21MMT _ Encryption & Application.
Topic no. 14: User Authentication.\
\
21127170 _ Nguyễn Thế Thiện\
21127679 _ Ngô Quốc Quý\
19127628 _ Nguyễn Mậu Việt\
